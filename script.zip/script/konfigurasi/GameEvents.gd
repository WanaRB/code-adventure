extends Node

var sudah_lewat_splash: bool = false
var sudah_lihat_howtoplay: bool = false

signal quiz_opened
signal quiz_closed
signal quiz_answered_correct(variant_idx: int, world_changes)
signal quiz_points_earned(correct_count: int, speed_bonus: int, wrong_count: int)
signal item_collected(points: int)
signal player_hit(damage_amount: int)
signal level_won
signal game_over
signal skill_terminal_closed
signal lever_pulled(laser_id: int)

signal quiz_highlight_updated(hl_idx: int, teks: String)

## State suara menu — true = hidup, false = mati. Dibaca semua scene menu.
var musik_menu_hidup: bool = true


var last_level_path: String = ""

## Poin sesi terakhir — diisi game_manager, dibaca lose_screen
var last_session_net: int = 0

var volume_musik: float = 0.5
var is_fullscreen: bool = false
